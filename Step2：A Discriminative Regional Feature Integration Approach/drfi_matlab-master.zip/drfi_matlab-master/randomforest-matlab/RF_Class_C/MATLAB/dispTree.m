function dispTree( t )
end